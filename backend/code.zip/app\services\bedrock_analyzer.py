"""Bedrock AI analysis service — calls Amazon Nova for intelligent analysis."""

import json
import re
from pathlib import Path

import structlog

from app.aws.bedrock import BedrockRepository
from app.core.settings import get_settings

logger = structlog.get_logger(__name__)

settings = get_settings()

PROMPTS_DIR = Path(__file__).parent.parent / "prompts"


def _load_prompt(name: str) -> str:
    path = PROMPTS_DIR / name
    if path.exists():
        return path.read_text(encoding="utf-8")
    logger.warning("prompt_file_not_found", name=name)
    return ""


def _validate_boundaries(data: dict) -> dict:
    if "services" not in data:
        data["services"] = []
    for svc in data["services"]:
        svc.setdefault("name", "UnknownService")
        svc.setdefault("description", "")
        svc.setdefault("cohesion_score", 50)
        svc.setdefault("coupling_score", 50)
        svc.setdefault("classes", [])
        svc.setdefault("packages", [])
        svc.setdefault("api_endpoints", [])
        svc.setdefault("database_tables", [])
        svc.setdefault("confidence", 50)
        svc.setdefault("readiness", "yellow")
        svc.setdefault("risk_level", "medium")
        svc.setdefault("business_capability", "")
        if svc["readiness"] not in ("green", "yellow", "red"):
            svc["readiness"] = "yellow"
        if svc["risk_level"] not in ("low", "medium", "high", "critical"):
            svc["risk_level"] = "medium"
    data.setdefault("total_services", len(data["services"]))
    data.setdefault("business_capabilities", [])
    return data


def _validate_readiness(data: dict) -> dict:
    defaults = {
        "code_quality": {"score": 0, "evidence": "No data"},
        "architecture": {"score": 0, "evidence": "No data"},
        "cloud_readiness": {"score": 0, "evidence": "No data"},
        "service_separation": {"score": 0, "evidence": "No data"},
        "database_coupling": {"score": 0, "evidence": "No data"},
        "documentation": {"score": 0, "evidence": "No data"},
        "overall": 0,
        "confidence": 0,
        "summary": "Analysis incomplete",
    }
    for key, default_val in defaults.items():
        if key not in data:
            data[key] = default_val
    if not isinstance(data.get("overall"), (int, float)):
        data["overall"] = 0
    return data


def _validate_adrs(data: dict) -> dict:
    if "adrs" not in data:
        data["adrs"] = []
    for adr in data["adrs"]:
        adr.setdefault("id", "ADR-000")
        adr.setdefault("title", "Unknown Decision")
        adr.setdefault("status", "Recommended")
        adr.setdefault("context", "")
        adr.setdefault("decision", "")
        adr.setdefault("alternatives", [])
        adr.setdefault("tradeoffs", {"pros": [], "cons": []})
        adr.setdefault("consequences", {"positive": [], "negative": [], "risks": []})
        adr.setdefault("confidence", 50)
        adr.setdefault("migration_impact", {
            "complexity": "medium", "estimated_effort": "TBD",
            "team_size": 2, "risk_factors": []
        })
    return data


def _validate_waves(data: dict) -> dict:
    if "waves" not in data:
        data["waves"] = []
    for wave in data["waves"]:
        wave.setdefault("wave_number", 1)
        wave.setdefault("name", "Unknown Wave")
        wave.setdefault("services", [])
        wave.setdefault("timeline_weeks", 4)
        wave.setdefault("estimated_engineers", 2)
        wave.setdefault("dependencies", [])
        wave.setdefault("risk_level", "medium")
        wave.setdefault("migration_complexity", "moderate")
        if wave["risk_level"] not in ("low", "medium", "high", "critical"):
            wave["risk_level"] = "medium"
    data.setdefault("total_weeks", sum(w.get("timeline_weeks", 4) for w in data["waves"]))
    data.setdefault("recommended_order", [])
    return data


def _truncate_to_budget(sections: list[tuple[str, str]], total_budget: int = 7000) -> str:
    if not sections:
        return ""
    header = sections[0][1] if sections[0][0] == "header" else ""
    footer = sections[-1][1] if sections[-1][0] == "footer" else ""
    content_sections = [(name, text) for name, text in sections if name not in ("header", "footer")]
    if not content_sections:
        return header + footer
    available = total_budget - len(header) - len(footer)
    if available <= 0:
        return header + footer
    total_content_len = sum(len(text) for _, text in content_sections)
    if total_content_len <= available:
        return header + "\n".join(text for _, text in content_sections) + footer
    result = header
    for name, text in content_sections:
        proportional = int((len(text) / total_content_len) * available)
        if len(text) > proportional:
            result += text[:proportional] + f"\n... [truncated {name}]\n"
        else:
            result += text + "\n"
    result += footer
    return result


def analyze_service_boundaries(analysis_data: dict) -> dict:
    prompt = _build_boundary_prompt(analysis_data)
    repo = BedrockRepository()
    response = repo.invoke(prompt, max_tokens=settings.bedrock_max_tokens)
    result = _parse_json_response(response)
    return _validate_boundaries(result)


def generate_readiness_scores(analysis_data: dict) -> dict:
    prompt = _build_readiness_prompt(analysis_data)
    repo = BedrockRepository()
    response = repo.invoke(prompt, max_tokens=settings.bedrock_max_tokens)
    result = _parse_json_response(response)
    return _validate_readiness(result)


def generate_adrs(analysis_data: dict, boundaries: list[dict]) -> dict:
    prompt = _build_adr_prompt(analysis_data, boundaries)
    repo = BedrockRepository()
    response = repo.invoke(prompt, max_tokens=settings.bedrock_max_tokens)
    result = _parse_json_response(response)
    return _validate_adrs(result)


def generate_migration_waves(boundaries: list[dict], readiness: dict) -> dict:
    prompt = _build_wave_prompt(boundaries, readiness)
    repo = BedrockRepository()
    response = repo.invoke(prompt, max_tokens=settings.bedrock_max_tokens)
    result = _parse_json_response(response)
    return _validate_waves(result)


def generate_cost_comparison(analysis_data: dict, boundaries: list[dict]) -> dict:
    prompt = _build_cost_prompt(analysis_data, boundaries)
    repo = BedrockRepository()
    response = repo.invoke(prompt, max_tokens=settings.bedrock_max_tokens)
    return _parse_json_response(response)


def generate_explainability(boundaries: list[dict], readiness: dict, analysis_data: dict) -> dict:
    prompt = _build_explainability_prompt(boundaries, readiness, analysis_data)
    repo = BedrockRepository()
    response = repo.invoke(prompt, max_tokens=settings.bedrock_max_tokens)
    return _parse_json_response(response)


def generate_service_code(service_name: str, boundary: dict, analysis_data: dict) -> dict:
    prompt = _build_codegen_prompt(service_name, boundary, analysis_data)
    repo = BedrockRepository()
    response = repo.invoke(prompt, max_tokens=settings.bedrock_max_tokens, model_id=settings.bedrock_model_codegen)
    return _parse_json_response(response)


def _parse_json_response(response: str) -> dict:
    json_match = re.search(r"\{[\s\S]*\}", response)
    if json_match:
        try:
            return json.loads(json_match.group())
        except json.JSONDecodeError:
            pass
    try:
        return json.loads(response)
    except json.JSONDecodeError:
        return {"raw_response": response, "parse_error": True}


def _build_boundary_prompt(data: dict) -> str:
    classes = data.get("classes", [])
    package_tree = data.get("package_tree", {})
    endpoints = data.get("endpoints", [])
    dependencies = data.get("dependency_edges", [])
    metrics = data.get("metrics", {})

    god_classes = metrics.get("god_classes", [])
    circular_deps = metrics.get("circular_dependencies", [])
    injection_deps = metrics.get("injection_dependencies", [])

    god_class_names = [g["name"] for g in god_classes]
    god_class_details = [f"- {g['name']}: {g['reason']}" for g in god_classes]

    classes_summary = []
    for c in classes[:100]:
        classes_summary.append({
            "name": c["name"],
            "package": c["package"],
            "loc": c["lines_of_code"],
            "methods": c["method_count"],
            "annotations": c.get("annotations", [])[:5],
            "deps": c.get("dependencies", [])[:10],
            "injected_fields": c.get("injected_fields", []),
            "is_entity": c.get("is_entity", False),
            "is_controller": c.get("is_controller", False),
            "is_service": c.get("is_service", False),
            "is_god_class": c["name"] in god_class_names,
        })

    base_prompt = _load_prompt("architecture.txt")
    return f"""{base_prompt}

CLASSES ({len(classes)} total):
{json.dumps(classes_summary, indent=2)[:6000]}

PACKAGE TREE:
{json.dumps(package_tree, indent=2)[:2000]}

API ENDPOINTS ({len(endpoints)}):
{json.dumps(endpoints[:30], indent=2)[:2000]}

DEPENDENCY EDGES ({len(dependencies)}):
{json.dumps(dependencies[:50], indent=2)[:2000]}

GOD CLASSES TO SPLIT (CRITICAL — must be decomposed):
{chr(10).join(god_class_details) if god_class_details else "None detected"}

INJECTION DEPENDENCIES ({len(injection_deps)}):
{json.dumps(injection_deps[:30], indent=2)[:2000]}

CIRCULAR DEPENDENCIES ({len(circular_deps)} total — these chains MUST be broken during extraction):
{json.dumps(circular_deps[:15], indent=2)[:3000]}

CRITICAL RULES:
1. USE ACTUAL CLASS NAMES: Name services using actual class names from the codebase.
2. GOD CLASSES MUST BE DECOMPOSED
3. Circular dependencies MUST be broken during extraction
4. Each service should own its database tables (no shared tables)
5. Group by BUSINESS DOMAIN, not technical layer
6. Services with LOW coupling scores should be extracted FIRST
7. MAP each service to specific source classes

Return JSON: {{"services": [list], "total_services": N, "business_capabilities": [list]}}"""


def _build_readiness_prompt(data: dict) -> str:
    metrics = data.get("metrics", {})
    god_classes = metrics.get("god_classes", [])
    circular_deps = metrics.get("circular_dependencies", [])
    dead_code = metrics.get("dead_code", [])
    shared_entities = metrics.get("shared_entities", [])

    circular_dep_descriptions = []
    for i, cd in enumerate(circular_deps[:15], 1):
        cycle = cd.get("cycle", [])
        cycle_type = cd.get("type", "import")
        chain = " -> ".join(cycle)
        circular_dep_descriptions.append(f"  {i}. [{cycle_type.upper()}] {chain}")

    circular_dep_text = "\n".join(circular_dep_descriptions) if circular_dep_descriptions else "  NONE DETECTED"
    num_circular = len(circular_deps)

    base_prompt = _load_prompt("summary.txt")
    return f"""{base_prompt}

METRICS:
- Total classes: {metrics.get('total_classes', 0)}
- Total LOC: {metrics.get('total_lines', 0)}
- God classes: {len(god_classes)}
- Circular dependencies: {num_circular}
- Dead code: {len(dead_code)}
- Shared entities: {len(shared_entities)}

GOD CLASSES:
{json.dumps(god_classes[:10], indent=2)[:2000]}

CIRCULAR DEPENDENCY CHAINS ({num_circular} total):
{circular_dep_text}

SCORING RULES:
- code_quality: If god classes exist, max 40. PatientService alone caps at 30.
- architecture: If circular deps exist, max 35.
- cloud_readiness: If god classes exist, max 35.
- service_separation: If circular deps exist, max 40.
- database_coupling: If shared entities exist, max 40.

ARCHITECTURE EVIDENCE MUST mention circular dependency chains by name.

Return JSON:
{{
  "code_quality": {{"score": N, "evidence": "..."}},
  "architecture": {{"score": N, "evidence": "MUST mention circular deps by name"}},
  "cloud_readiness": {{"score": N, "evidence": "..."}},
  "service_separation": {{"score": N, "evidence": "..."}},
  "database_coupling": {{"score": N, "evidence": "..."}},
  "documentation": {{"score": N, "evidence": "..."}},
  "overall": N,
  "confidence": N,
  "summary": "..."
}}"""


def _build_adr_prompt(data: dict, boundaries: list) -> str:
    metrics = data.get("metrics", {})
    god_classes = metrics.get("god_classes", [])
    circular_deps = metrics.get("circular_dependencies", [])

    service_evidence = []
    for s in boundaries[:10]:
        svc_name = s.get("name", "")
        svc_classes = s.get("classes", [])
        affected_god_classes = [g for g in god_classes if g["name"] in svc_classes]
        affected_circular = [
            c for c in circular_deps
            if any(cls in svc_classes for cls in c.get("cycle", []))
        ]
        service_evidence.append({
            "service": svc_name,
            "classes": svc_classes,
            "coupling_score": s.get("coupling_score", 50),
            "risk_level": s.get("risk_level", "medium"),
            "god_classes_in_service": affected_god_classes,
            "circular_deps_involving": affected_circular,
        })

    base_prompt = _load_prompt("adr.txt")
    return f"""{base_prompt}

SERVICE EVIDENCE:
{json.dumps(service_evidence, indent=2)[:6000]}

CRITICAL RULES:
1. Each ADR context MUST reference specific god classes or circular dependencies by name
2. Each ADR tradeoffs.cons MUST include 2+ service-specific risks
3. Do NOT use the same template for all ADRs

Return JSON: {{"adrs": [list of ADR objects]}}"""


def _build_wave_prompt(boundaries: list, readiness: dict) -> str:
    coupling_data = sorted(boundaries, key=lambda x: x.get("coupling_score", 100))

    service_deps = {}
    service_names = {s["name"] for s in coupling_data}
    class_to_service = {}
    for s in coupling_data:
        for cls in s.get("classes", []):
            class_to_service[cls] = s["name"]

    for s in coupling_data:
        svc_name = s["name"]
        deps = set()
        for inj in s.get("injected_fields", []):
            if inj in class_to_service and class_to_service[inj] != svc_name:
                deps.add(class_to_service[inj])
        service_deps[svc_name] = list(deps)

    base_prompt = _load_prompt("migration.txt")
    return f"""{base_prompt}

SERVICES (sorted by coupling — LOWEST first = extract FIRST):
{json.dumps(coupling_data, indent=2)[:5000]}

SERVICE DEPENDENCY GRAPH:
{json.dumps(service_deps, indent=2)[:2000]}

READINESS:
{json.dumps(readiness, indent=2)[:2000]}

WAVE PLANNING RULES:
1. Wave 1: LOWEST coupling (< 30), LOW risk. 1-2 services max.
2. Wave 2: Low-medium coupling (30-50). 1-2 services.
3. Wave 3: MEDIUM coupling (50-70). 1-2 services.
4. Wave 4: HIGHER coupling (>70) or CIRCULAR DEPENDENCIES.
5. Wave 5: GOD CLASS services needing decomposition.
6. Max 2 services per wave unless trivially simple.
7. Services with CIRCULAR DEPENDENCIES must be in consecutive waves.

Return JSON: {{"waves": [list], "total_weeks": N, "recommended_order": [list]}}"""


def _build_cost_prompt(data: dict, boundaries: list) -> str:
    metrics = data.get("metrics", {})
    return f"""You are an AWS cost optimization expert.

Estimate cost comparison between monolith and proposed microservices.

MONOLITH:
- LOC: {metrics.get('total_lines', 0)}
- Classes: {metrics.get('total_classes', 0)}
- Endpoints: {len(data.get('endpoints', []))}

PROPOSED SERVICES: {len(boundaries)} microservices

Return JSON:
{{
  "current_monthly": N,
  "post_migration_monthly": N,
  "monthly_savings": N,
  "annual_savings": N,
  "one_time_cost": N,
  "payback_months": N,
  "breakdown_current": {{"infrastructure": N, "operations": N, "development": N}},
  "breakdown_post": {{"infrastructure": N, "operations": N, "development_savings": N}},
  "migration_impact": {{
    "total_services": N,
    "total_waves": N,
    "estimated_timeline_weeks": N,
    "total_engineers_needed": N,
    "risk_summary": "..."
  }}
}}"""


def _build_explainability_prompt(boundaries: list, readiness: dict, data: dict) -> str:
    return f"""You are an AI explainability expert.

For each service recommendation, provide detailed reasoning.

RECOMMENDATIONS:
{json.dumps(boundaries[:5], indent=2)[:4000]}

For each service, explain:
1. Why this service was recommended
2. Evidence from code analysis
3. Confidence breakdown by factor

Return JSON:
{{
  "recommendations": [
    {{
      "service": "ServiceName",
      "confidence": N,
      "primary_reason": "...",
      "secondary_reasons": ["..."],
      "evidence": {{"code_isolation": "..."}},
      "migration_complexity": "simple|moderate|complex"
    }}
  ],
  "business_capabilities": ["..."],
  "risk_heatmap": [{{"service": "Name", "risk_level": "low|medium|high", "risk_factors": ["..."]}}]
}}"""


def _build_codegen_prompt(service_name: str, boundary: dict, data: dict) -> str:
    return f"""You are a Java Spring Boot expert generating production-ready microservice code.

Generate complete code for: {service_name}

BOUNDARY:
{json.dumps(boundary, indent=2)[:3000]}

Generate these files:
1. Controller class
2. Service class
3. Repository class
4. Model/Entity class
5. DTO classes
6. Dockerfile
7. pom.xml
8. application.yml
9. CDK stack
10. OpenAPI 3.0 spec

Return JSON:
{{
  "files": [{{"path": "src/main/java/.../Xxx.java", "content": "..."}}],
  "compilation_notes": "...",
  "deployment_notes": "..."
}}"""
