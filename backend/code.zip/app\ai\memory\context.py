"""AI Memory Context — prepares context window from stored memories.

Architecture only — Sprint 4 implementation.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from app.ai.memory.store import MemoryEntry, MemoryStore


@dataclass
class MemoryContext:
    """Prepared context window assembled from memory entries.

    Future: will be used to provide conversational context for follow-up
    queries about the same analysis job.
    """
    job_id: str = ""
    session_id: str = ""
    entries: list[MemoryEntry] = field(default_factory=list)
    total_tokens_estimate: int = 0
    truncated: bool = False

    def to_prompt_context(self, max_tokens: int = 4000) -> str:
        """Convert memory entries into a prompt-compatible context string."""
        if not self.entries:
            return ""

        lines = ["PREVIOUS ANALYSIS CONTEXT:"]
        for entry in self.entries:
            lines.append(f"[{entry.role.upper()}] {entry.content[:500]}")

        context = "\n".join(lines)
        if len(context) > max_tokens * 4:
            context = context[:max_tokens * 4]
            self.truncated = True

        return context


class MemoryContextBuilder:
    """Builds MemoryContext from MemoryStore for a given job.

    Architecture preparation — not yet integrated.
    """

    def __init__(self, store: MemoryStore):
        self._store = store

    def build(self, job_id: str, session_id: str = "", max_entries: int = 10) -> MemoryContext:
        """Build context from recent memories."""
        entries = self._store.retrieve(job_id, limit=max_entries)

        return MemoryContext(
            job_id=job_id,
            session_id=session_id,
            entries=entries,
            total_tokens_estimate=sum(len(e.content) // 4 for e in entries),
        )
